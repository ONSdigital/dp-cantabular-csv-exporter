package cantabular

// Config holds the config used to initialise the Cantabular Client
type Config struct{
	Host    string
}