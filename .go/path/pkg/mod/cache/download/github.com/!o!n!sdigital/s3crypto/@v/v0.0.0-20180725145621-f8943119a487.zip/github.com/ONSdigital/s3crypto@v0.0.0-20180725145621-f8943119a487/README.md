# s3encrypt

A Client Side encryption wrapper for the AWS SDK for S3 

Compatible with https://github.com/ONSdigital/java-s3crypto

See example folder for example usage
