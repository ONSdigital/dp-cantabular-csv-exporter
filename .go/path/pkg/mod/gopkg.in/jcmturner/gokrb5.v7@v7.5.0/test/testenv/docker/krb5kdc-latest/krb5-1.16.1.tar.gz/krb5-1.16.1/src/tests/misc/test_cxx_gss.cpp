// Test that the gssapi.h header is compatible with C++ application code.

#include <stdio.h>
#include "gssapi/gssapi.h"

int main ()
{
    printf("hello, world\n");
    return 0;
}
