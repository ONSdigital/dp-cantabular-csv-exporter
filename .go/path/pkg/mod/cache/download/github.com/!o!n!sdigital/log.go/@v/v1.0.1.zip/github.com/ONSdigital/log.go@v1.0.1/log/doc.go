// Package log is a log library which implements the Digital Publishing logging standards
package log
